# EMA Tournament — FPS multijoueur (Team Deathmatch)

FPS multijoueur en C avec [raylib](https://www.raylib.com/) : deux équipes
(rouge vs bleue) s'affrontent dans un match à mort par équipe. Première
équipe à **30 kills** gagne.

Les joueurs humains incarnent des **soldats-mercenaires** (treillis olive,
visage peint en vert, yeux injectés de sang, démarche bras tendus) ; les
bots sont des **poussins zombies** humanoïdes ensanglantés, tout droit
sortis d'un film d'horreur. Épaulettes, brassards et colliers prennent la
couleur de l'équipe.

## Architecture

```
src/
├── common/           Code partagé par les trois programmes
│   ├── protocol.h    Protocole réseau UDP (paquets, constantes)
│   └── game.h/.c     Règles, map (AABB), collisions, raycasts
├── server/main.c     Serveur dédié headless (autoritaire)
├── client/main.c     Client raylib (vue FPS, prédiction, HUD)
├── client/models.c   Modèles 3D procéduraux (soldat, poussin zombie)
└── bot/main.c        Bot zombie headless (pour le dev et le test)
```

- **Transport** : UDP, paquets binaires packés (`#pragma pack`).
- **Serveur autoritaire** sur les tirs (raycast serveur), la vie, les
  kills, les scores et les respawns. Il valide l'expéditeur de chaque
  paquet (id + adresse), l'origine des tirs, et rejette les positions
  datant d'avant un respawn (compteur `spawn_count`).
- **Client prédictif** : le déplacement est simulé localement (fluide
  quel que soit le ping) et envoyé 30×/s ; les autres joueurs sont
  interpolés entre les snapshots (20 Hz).

## Vue FPS

- Arme dessinée en « view model » : passe 3D séparée en espace vue, elle
  ne rentre jamais dans les murs. Balancement de marche, sway (l'arme
  traîne derrière la souris), recul (kick) et flash de bouche.
- Visée (clic droit) : zoom de FOV, sensibilité réduite, point rouge du
  viseur au centre de l'écran, dispersion minimale.
- Sprint (Maj + avant) : FOV élargi, arme baissée, tir impossible.
- Dispersion réaliste : précise en visant, imprécise en courant, en
  sautant ou en rafale (bloom) — le réticule s'écarte pour la montrer.
- Head bob à la marche, caméra qui s'effondre à la mort, recul qui fait
  réellement monter la vue (et les balles).

## Compilation (macOS)

```sh
brew install raylib
make
```

Produit `build/server`, `build/client` et `build/bot`. Le serveur et le
bot ne dépendent pas de raylib (ils tournent sans affichage).

## Lancer une partie

```sh
# Terminal 1 : le serveur (port 7777 par défaut)
./build/server

# Terminal 2 : votre client
./build/client 127.0.0.1 Alice

# Terminal 3 : un bot zombie pour avoir un adversaire (dev/test)
./build/bot 127.0.0.1 Zombie
```

Pour jouer en LAN, remplacer `127.0.0.1` par l'IP de la machine serveur.
L'équipe est attribuée automatiquement (auto-équilibrage) : connectez le
bot **après** vous pour qu'il soit dans l'équipe adverse.

### Le bot zombie

Headless, il chasse l'ennemi vivant le plus proche, contourne (grossièrement)
les obstacles en sautant et en faisant des pas de côté quand il est coincé,
et griffe au corps-à-corps (25 dégâts toutes les 0,9 s). Ses réglages sont en
tête de [src/bot/main.c](src/bot/main.c).

## Contrôles

| Touche | Action |
|---|---|
| W / A / S / D | Se déplacer (position physique des touches : ZQSD en AZERTY) |
| Souris | Viser |
| Clic gauche | Tirer (automatique maintenu) |
| Clic droit | Viser (zoom) |
| Maj gauche | Sprint (en avançant) |
| Espace | Sauter |
| Tab | Tableau des scores |
| Échap | Quitter |

## Réglages de gameplay

Tout est dans [src/common/game.h](src/common/game.h) : dégâts, cadence,
vitesse, gravité, délai de respawn, limite de score... et la map elle-même
dans [src/common/game.c](src/common/game.c) (liste de boîtes `MAP_BOXES`).
Les réglages de la vue FPS (FOV, sensibilité, accélérations) sont en tête
de [src/client/main.c](src/client/main.c).

## Pistes pour la suite

- Lag compensation (rembobiner les positions pour valider les tirs)
- Anti-triche sur le déplacement (valider la vitesse côté serveur)
- Plusieurs armes, munitions, rechargement
- Animation d'attaque du poussin zombie (bond, bec qui claque)
- Sons (tirs, hits, cris de poussin)
- Chat texte, menu de connexion in-game
