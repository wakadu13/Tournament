/*
 * models.c — Modèles 3D procéduraux des personnages.
 *
 * Technique : chaque personnage est décrit dans son REPÈRE LOCAL
 * (origine entre les pieds au sol, +Y vers le haut, +Z vers l'avant,
 * +X vers la gauche du personnage, unités en mètres), puis posé dans le
 * monde par la pile de matrices rlgl : rlTranslatef (position) suivi de
 * rlRotatef (orientation). Toutes les primitives raylib (DrawSphere,
 * DrawCube, DrawCylinderEx...) passent par cette pile, donc tout ce qui
 * est dessiné entre rlPushMatrix et rlPopMatrix suit le personnage.
 *
 * Primitives maison (mêmes noms que dans le premier jeu) :
 *   Ball(centre, rayons, couleur)  ellipsoïde (sphère étirée par rlScalef)
 *   Box3(centre, rot, taille, c)   pavé éventuellement tourné (radians XYZ)
 *   Seg(a, b, rayon, c)            cylindre entre deux points
 *   Limb(a, b, rayon, c)           cylindre + boules aux deux bouts
 *                                  (une articulation arrondie : bras, jambe)
 */
#include <math.h>

#include "raylib.h"
#include "raymath.h"   // Vector3Lerp
#include "rlgl.h"

#include "models.h"

// RAD2DEG existe déjà dans raylib ; rlRotatef attend des degrés
static void RotXYZ(Vector3 r)
{
    // Même ordre que MatrixRotateXYZ : Z, puis Y, puis X
    if (r.z != 0) rlRotatef(r.z * RAD2DEG, 0, 0, 1);
    if (r.y != 0) rlRotatef(r.y * RAD2DEG, 0, 1, 0);
    if (r.x != 0) rlRotatef(r.x * RAD2DEG, 1, 0, 0);
}

// Ellipsoïde : sphère unité écrasée/étirée par un rlScalef
static void Ball(Vector3 c, Vector3 radii, Color col)
{
    rlPushMatrix();
    rlTranslatef(c.x, c.y, c.z);
    rlScalef(radii.x, radii.y, radii.z);
    DrawSphereEx((Vector3){0, 0, 0}, 1.0f, 8, 10, col);
    rlPopMatrix();
}

// Pavé tourné de rot (radians autour de X, Y, Z)
static void Box3(Vector3 c, Vector3 rot, Vector3 size, Color col)
{
    rlPushMatrix();
    rlTranslatef(c.x, c.y, c.z);
    RotXYZ(rot);
    DrawCube((Vector3){0, 0, 0}, size.x, size.y, size.z, col);
    rlPopMatrix();
}

// Cylindre entre deux points (DrawCylinderEx gère l'orientation lui-même,
// ses sommets passent par la pile de matrices comme tout le reste)
static void Seg(Vector3 a, Vector3 b, float radius, Color col)
{
    DrawCylinderEx(a, b, radius, radius, 6, col);
}

// Membre : cylindre + rotules arrondies aux extrémités
static void Limb(Vector3 a, Vector3 b, float radius, Color col)
{
    Seg(a, b, radius, col);
    DrawSphereEx(a, radius, 6, 8, col);
    DrawSphereEx(b, radius, 6, 8, col);
}

// Assombrit/éclaircit une couleur (k < 1 = plus sombre)
static Color Shade(Color c, float k)
{
    return (Color){(unsigned char)fminf(c.r * k, 255.0f),
                   (unsigned char)fminf(c.g * k, 255.0f),
                   (unsigned char)fminf(c.b * k, 255.0f), c.a};
}

//----------------------------------------------------------------------------------
// Le soldat-mercenaire (modèle des joueurs humains)
//----------------------------------------------------------------------------------
// Silhouette reprise du premier jeu : treillis olive aux manches
// retroussées, visage entièrement peint en vert aux yeux cernés de noir et
// injectés de sang, cheveux ras, rangers, démarche de zombie bras tendus
// vers l'avant. Les épaulettes et le brassard prennent la couleur de
// l'équipe pour reconnaître amis et ennemis d'un coup d'œil.
void DrawSoldier(Vector3 pos, float yaw, float walk_phase, float move,
                 Color team_color)
{
    // Palette (reprise du premier jeu)
    const Color UNIFORM = {88, 96, 68, 255};     // treillis olive
    const Color PANTS   = Shade(UNIFORM, 0.8f);  // pantalon plus sombre
    const Color SKIN    = {222, 172, 140, 255};  // peau des avant-bras
    const Color PAINT   = {112, 126, 80, 255};   // visage peint en vert
    const Color PAINT_BLACK = {24, 26, 22, 255}; // cernes noirs
    const Color EYE_WHITE = {238, 212, 206, 255};// yeux injectés
    const Color HAIR    = {50, 38, 28, 255};     // cheveux ras
    const Color BOOTS   = {28, 26, 24, 255};     // rangers
    const Color BLOOD   = {168, 24, 20, 255};    // taches sur le brassard

    // Balancement de marche : bras et jambes en opposition, amplitude
    // proportionnelle à move (immobile = 0)
    float sw = sinf(walk_phase) * move;
    // Petit rebond vertical à chaque pas (|sin| = deux bosses par cycle)
    float bob = fabsf(sinf(walk_phase)) * 0.035f * move;

    rlPushMatrix();
    rlTranslatef(pos.x, pos.y, pos.z);
    rlRotatef(yaw * RAD2DEG, 0, 1, 0);   // tout le reste est en repère local

    // --- Jambes (sous le rebond : elles restent posées au sol) ---
    for (int k = -1; k <= 1; k += 2) {   // k = -1 : droite, k = +1 : gauche
        float swing = sw * k * 0.24f;            // le pied avance ou recule
        float lift = fmaxf(0, -swing) * 0.18f;   // il se soulève en reculant
        Vector3 hip = {0.1f * k, 0.95f, 0};
        Vector3 foot = {0.12f * k, 0.1f + lift, swing};
        // Genou à mi-chemin, un peu en avant : la jambe plie dans le bon sens
        Vector3 knee = {(hip.x + foot.x) / 2, 0.52f + lift * 0.5f,
                        (hip.z + foot.z) / 2 + 0.05f};
        Limb(hip, knee, 0.085f, PANTS);          // cuisse
        Seg(knee, (Vector3){foot.x, foot.y + 0.12f, foot.z}, 0.075f, PANTS); // tibia
        Seg(foot, (Vector3){foot.x, foot.y + 0.16f, foot.z}, 0.072f, BOOTS); // tige de la botte
        Box3((Vector3){foot.x, 0.05f, foot.z + 0.04f}, (Vector3){0},
             (Vector3){0.11f, 0.1f, 0.26f}, BOOTS);   // le pied
    }

    rlTranslatef(0, bob, 0);   // tout le haut du corps rebondit à la marche

    // --- Bassin, ceinturon ---
    Ball((Vector3){0, 0.98f, 0}, (Vector3){0.185f, 0.12f, 0.125f}, PANTS);
    Ball((Vector3){0, 1.04f, 0}, (Vector3){0.19f, 0.035f, 0.132f},
         (Color){24, 24, 24, 255});

    // --- Torse : trois ellipsoïdes (taille, poitrine, épaules) ---
    Ball((Vector3){0, 1.1f, 0}, (Vector3){0.19f, 0.17f, 0.13f}, UNIFORM);
    Ball((Vector3){0, 1.33f, 0.012f}, (Vector3){0.215f, 0.2f, 0.14f}, UNIFORM);
    Ball((Vector3){0, 1.48f, 0}, (Vector3){0.25f, 0.09f, 0.13f}, UNIFORM);

    // --- Bras tendus vers l'avant, démarche de zombie (comme le premier
    // jeu) : ils balancent doucement en opposition à la marche ---
    for (int k = -1; k <= 1; k += 2) {
        float s = sw * k;
        Vector3 shoulder = {0.235f * k, 1.47f, 0};
        Vector3 elbow = {0.26f * k, 1.42f + s * 0.02f, 0.27f + s * 0.04f};
        Vector3 hand = {0.21f * k, 1.44f + s * 0.05f, 0.54f + s * 0.06f};
        // Manche retroussée : treillis jusqu'à 82 % du coude, revers roulé
        Vector3 cuff = Vector3Lerp(shoulder, elbow, 0.82f);
        Limb(shoulder, cuff, 0.062f, UNIFORM);
        Seg(cuff, Vector3Lerp(shoulder, elbow, 0.95f), 0.07f, Shade(UNIFORM, 0.9f));
        // Avant-bras nu et main
        Limb(elbow, hand, 0.042f, SKIN);
        Ball(hand, (Vector3){0.045f, 0.055f, 0.04f}, SKIN);
        // Épaulette à la couleur de l'équipe, inclinée avec l'épaule
        Box3((Vector3){0.15f * k, 1.562f, 0}, (Vector3){0, 0, -0.27f * k},
             (Vector3){0.1f, 0.02f, 0.07f}, team_color);
    }
    // Brassard d'équipe sur le bras gauche, taché de sang
    Seg((Vector3){0.245f, 1.455f, 0.08f}, (Vector3){0.255f, 1.44f, 0.17f},
        0.071f, team_color);
    Ball((Vector3){0.3f, 1.45f, 0.12f}, (Vector3){0.012f, 0.022f, 0.014f}, BLOOD);
    Ball((Vector3){0.29f, 1.44f, 0.16f}, (Vector3){0.012f, 0.016f, 0.02f}, BLOOD);

    // --- Tête : visage entièrement peint en vert ---
    Seg((Vector3){0, 1.5f, -0.005f}, (Vector3){0, 1.68f, 0.01f}, 0.052f, PAINT); // cou
    Ball((Vector3){0, 1.69f, 0.025f}, (Vector3){0.085f, 0.06f, 0.085f}, PAINT);  // mâchoire
    Ball((Vector3){0, 1.775f, 0.012f}, (Vector3){0.105f, 0.13f, 0.115f}, PAINT); // crâne
    for (int k = -1; k <= 1; k += 2)   // oreilles (peau, pas peintes)
        Ball((Vector3){0.103f * k, 1.765f, -0.005f}, (Vector3){0.018f, 0.04f, 0.028f}, SKIN);
    // Cheveux : rasés sur les côtés (calotte sombre), plus fournis dessus
    Ball((Vector3){0, 1.79f, -0.02f}, (Vector3){0.108f, 0.118f, 0.1f}, Shade(HAIR, 0.75f));
    Ball((Vector3){0, 1.86f, 0.008f}, (Vector3){0.092f, 0.06f, 0.1f}, HAIR);

    // Yeux : cerne noir, blanc injecté de sang, pupille sombre
    for (int k = -1; k <= 1; k += 2) {
        Ball((Vector3){0.037f * k, 1.787f, 0.1f}, (Vector3){0.03f, 0.024f, 0.012f}, PAINT_BLACK);
        Ball((Vector3){0.037f * k, 1.787f, 0.106f}, (Vector3){0.024f, 0.017f, 0.012f}, EYE_WHITE);
        Ball((Vector3){0.037f * k, 1.787f, 0.115f}, (Vector3){0.009f, 0.01f, 0.005f},
             (Color){40, 28, 20, 255});
        // Coulure de peinture noire sous l'œil
        Ball((Vector3){0.036f * k, 1.74f, 0.105f}, (Vector3){0.012f, 0.045f, 0.008f}, PAINT_BLACK);
    }
    // Nez et bouche
    Ball((Vector3){0, 1.76f, 0.122f}, (Vector3){0.018f, 0.03f, 0.022f}, Shade(PAINT, 1.05f));
    Ball((Vector3){0, 1.71f, 0.105f}, (Vector3){0.035f, 0.008f, 0.012f},
         (Color){60, 18, 18, 255});

    rlPopMatrix();
}

//----------------------------------------------------------------------------------
// Le poussin zombie (modèle des bots)
//----------------------------------------------------------------------------------
// Un poussin humanoïde d'1m60, jaune sale, couvert de sang, les orbites
// noires et vides percées d'une lueur rouge, le bec grand ouvert qui
// dégouline, les ailes-bras tendues vers sa proie. Il se dandine en
// marchant et sa tête penche par à-coups (petit tic d'épouvante).
void DrawZombieChick(Vector3 pos, float yaw, float walk_phase, float move,
                     Color team_color)
{
    // Jaune terne de plumes sales, et ses déclinaisons
    // (FEATHER/BEAK plutôt que YELLOW/ORANGE : ce sont des macros raylib)
    const Color FEATHER = {208, 178, 70, 255};
    const Color WING   = Shade(FEATHER, 0.88f);
    const Color BEAK   = {230, 120, 25, 255};  // bec et pattes
    const Color BLOOD  = {150, 18, 14, 255};   // sang séché
    const Color BLOOD2 = {190, 30, 22, 255};   // sang frais
    const Color SOCKET = {12, 10, 10, 255};    // orbites vides
    const Color GLOW   = {255, 40, 30, 255};   // lueur rouge au fond

    float sw = sinf(walk_phase) * move;           // balancement des pattes
    float waddle = sinf(walk_phase * 0.5f) * 0.1f * move;  // dandinement (roulis)
    // Tic de tête : penche lentement puis se redresse d'un coup
    float twitch = sinf(walk_phase * 0.7f + 1.0f) * 0.2f;

    rlPushMatrix();
    rlTranslatef(pos.x, pos.y, pos.z);
    rlRotatef(yaw * RAD2DEG, 0, 1, 0);
    rlRotatef(waddle * RAD2DEG, 0, 0, 1);   // tout le corps se dandine

    // --- Pattes griffues (orange sale) ---
    for (int k = -1; k <= 1; k += 2) {
        float swing = sw * k * 0.22f;
        Vector3 hip = {0.16f * k, 0.6f, 0};
        Vector3 foot = {0.19f * k, 0.07f, swing};
        Limb(hip, foot, 0.06f, BEAK);
        // Pied en éventail : trois doigts griffus vers l'avant
        for (int t = -1; t <= 1; t++)
            Box3((Vector3){foot.x + t * 0.06f, 0.035f, foot.z + 0.14f},
                 (Vector3){0, t * 0.3f, 0}, (Vector3){0.045f, 0.045f, 0.24f}, BEAK);
    }

    // --- Corps dodu + queue ---
    Ball((Vector3){0, 0.82f, 0}, (Vector3){0.42f, 0.4f, 0.46f}, FEATHER);
    Ball((Vector3){0, 1.0f, -0.42f}, (Vector3){0.16f, 0.12f, 0.16f}, FEATHER);
    // Ventre éventré : grande tache de sang et entailles sombres
    Ball((Vector3){0.1f, 0.78f, 0.4f}, (Vector3){0.16f, 0.2f, 0.05f}, BLOOD);
    Ball((Vector3){0.12f, 0.72f, 0.43f}, (Vector3){0.05f, 0.12f, 0.03f}, (Color){60, 8, 8, 255});
    Ball((Vector3){-0.2f, 0.95f, 0.33f}, (Vector3){0.1f, 0.08f, 0.05f}, BLOOD);
    Ball((Vector3){0.28f, 0.6f, 0.28f}, (Vector3){0.07f, 0.1f, 0.05f}, BLOOD);

    // --- Collier à la couleur de l'équipe (pour reconnaître son camp) ---
    Ball((Vector3){0, 1.16f, 0.05f}, (Vector3){0.26f, 0.035f, 0.26f}, team_color);

    // --- Ailes-bras tendues vers l'avant, comme un zombie ---
    for (int k = -1; k <= 1; k += 2) {
        float s = sw * k;
        Vector3 shoulder = {0.38f * k, 1.0f, 0.1f};
        Vector3 tip = {0.3f * k, 0.92f + s * 0.05f, 0.62f + s * 0.06f};
        Limb(shoulder, tip, 0.09f, WING);
        // Bout de l'aile taché de sang + trois "griffes" de plumes
        Ball(tip, (Vector3){0.1f, 0.08f, 0.1f}, BLOOD2);
        for (int t = -1; t <= 1; t++)
            Box3((Vector3){tip.x + t * 0.05f, tip.y, tip.z + 0.12f},
                 (Vector3){0, t * 0.25f, 0}, (Vector3){0.03f, 0.03f, 0.16f}, WING);
    }

    // --- Tête : grosse boule qui penche par à-coups ---
    rlPushMatrix();
    rlTranslatef(0, 1.32f, 0.1f);                 // pivot à la base du cou
    rlRotatef(twitch * RAD2DEG, 0, 0, 1);         // le tic d'épouvante
    Ball((Vector3){0, 0.22f, 0.03f}, (Vector3){0.34f, 0.32f, 0.34f}, FEATHER);
    // Houppette : trois plumes dressées
    Ball((Vector3){0, 0.56f, -0.02f}, (Vector3){0.016f, 0.09f, 0.016f}, FEATHER);
    Ball((Vector3){0.05f, 0.54f, 0.0f}, (Vector3){0.014f, 0.07f, 0.014f}, FEATHER);
    Ball((Vector3){-0.04f, 0.53f, 0.03f}, (Vector3){0.014f, 0.06f, 0.014f}, FEATHER);
    // Sang qui a coulé du sommet du crâne
    Ball((Vector3){0.1f, 0.42f, 0.15f}, (Vector3){0.1f, 0.12f, 0.05f}, BLOOD);

    // Orbites noires et vides, percées d'une lueur rouge, larmes de sang
    for (int k = -1; k <= 1; k += 2) {
        Ball((Vector3){0.14f * k, 0.28f, 0.27f}, (Vector3){0.075f, 0.09f, 0.05f}, SOCKET);
        Ball((Vector3){0.14f * k, 0.28f, 0.3f}, (Vector3){0.028f, 0.028f, 0.02f}, GLOW);
        Ball((Vector3){0.14f * k, 0.13f, 0.3f}, (Vector3){0.02f, 0.1f, 0.012f}, BLOOD2);
    }

    // Bec grand ouvert, intérieur sombre, sang qui dégouline
    Box3((Vector3){0, 0.17f, 0.4f}, (Vector3){-0.25f, PI / 4, 0},
         (Vector3){0.16f, 0.05f, 0.16f}, BEAK);              // demi-bec haut
    Box3((Vector3){0, 0.06f, 0.37f}, (Vector3){0.35f, PI / 4, 0},
         (Vector3){0.14f, 0.04f, 0.14f}, Shade(BEAK, 0.85f)); // demi-bec bas
    Ball((Vector3){0, 0.11f, 0.33f}, (Vector3){0.07f, 0.05f, 0.05f},
         (Color){40, 6, 6, 255});                               // gosier sombre
    Ball((Vector3){0.02f, -0.02f, 0.4f}, (Vector3){0.018f, 0.09f, 0.012f}, BLOOD2); // filet de sang
    rlPopMatrix();   // fin de la tête

    rlPopMatrix();   // fin du poussin
}
