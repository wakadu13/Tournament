/*
 * models.h — Modèles 3D procéduraux des personnages (côté client).
 *
 * Deux modèles, entièrement construits à partir de primitives (ellipsoïdes,
 * cylindres, boîtes), dans le style du premier jeu :
 *   - DrawSoldier : le soldat-mercenaire qui incarne les JOUEURS humains
 *     (treillis olive, visage peint en vert, yeux injectés de sang,
 *     démarche de zombie bras tendus),
 *   - DrawZombieChick : le poussin humanoïde ensanglanté qui incarne les
 *     BOTS zombies (sorti tout droit d'un film d'horreur).
 *
 * Les deux reçoivent :
 *   pos        position des pieds dans le monde,
 *   yaw        orientation (radians, 0 = regarde vers +Z),
 *   walk_phase phase de l'animation de marche (avance avec la distance
 *              parcourue : voir l'appelant),
 *   move       0..1 : à quel point le personnage se déplace (amplitude
 *              du balancement des jambes/bras),
 *   team_color couleur de l'équipe (épaulettes/brassard du soldat,
 *              collier du poussin) pour reconnaître amis et ennemis.
 */
#ifndef MODELS_H
#define MODELS_H

#include "raylib.h"

void DrawSoldier(Vector3 pos, float yaw, float walk_phase, float move,
                 Color team_color);
void DrawZombieChick(Vector3 pos, float yaw, float walk_phase, float move,
                     Color team_color);

#endif // MODELS_H
